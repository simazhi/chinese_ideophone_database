#' CHIDEOR
#' A data package for CHIDEOR.
#' @docType package
#' @aliases CHIDEOR-package
#' @title Package Title
#' @name CHIDEOR
#' @description A description of the data package
#' @details Use \code{data(package='CHIDEOR')$results[, 3]} to see a list of available data sets in this data package
#'     and/or DataPackageR::load_all
#' _datasets() to load them.
#' @seealso
#' NA
#' \link{CHIDEOR}
NULL



